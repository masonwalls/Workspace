// Mason Walls 1/11/24 Chapter 1 In class activity 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Oscillate yourelf tonight");
		System.out.println("when you're in your bed");
		System.out.println("Assimilate the dopamine");
		System.out.println("passing through your head");
	}

}
