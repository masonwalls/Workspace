// Mason Walls 1/11/24 Chapter 1 in class activity 2
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Some of you may die, but that is a sacrafice I am willing to take.");
		System.out.println("Said by Lord Farquaad");
		System.out.println("Shrek");
		System.out.println("Year 2001");
	}

}
